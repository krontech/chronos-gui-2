import time
import pdb





class IOObject:
	'''all the IO!
	STILL TO BE IMPLEMENTED'''

	def __init__(self):
		cprint ("IOObject Init", "yellow")


	def setTriggerEnable(self):



	def setTriggerInvert(self):



	def setTriggerDebounceEn(self):




	def setTriggerDelayFrames(self):




	def setShutterGatingEnable(self):

